package GUI;

import Controller.Controller;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;



import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Time;
import java.util.Locale;

public class Tabellone {
    public Container tabellonePanel;
    private JPanel Tabellone;
    private JList list1;
    private JComboBox lista_natanti;
    private JButton login;
    private JTextField partenza;
    private JTextField arrivo;
    private JTextField data;
    private JTextField ora;
    private JTextField giorno;
    private JTextField prezzo_min;
    private JPanel ListaP;
    private JPanel TitoloP;
    private JScrollPane Lista;
    private JPanel IndietroP;
    private JPanel Filtri1P;
    private JPanel FiltroNP;
    private JPanel FiltroPP;
    private JTextField prezzo_max;
    private JButton INVIA;
    private JTable table1;
    private JButton biglietti;

    private Controller controller;

    public Tabellone(Controller controller) {
        this.controller = controller;
        tabellonePanel = Tabellone;

        INVIA.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Recupera i dati inseriti dall'utente
                String partenzaText = partenza.getText();
                String arrivoText = arrivo.getText();
                String dataText = data.getText();
                String oraText = ora.getText();
                String giornoText = giorno.getText();
                String prezzoMinText = prezzo_min.getText();
                String prezzoMaxText = prezzo_max.getText();
                String natanteText = (String) lista_natanti.getSelectedItem();

                // Stampa dei dati inseriti per il debug
                System.out.println("Dati inseriti:");
                System.out.println("Partenza: " + partenzaText);
                System.out.println("Arrivo: " + arrivoText);
                System.out.println("Data: " + dataText);
                System.out.println("Ora: " + oraText);
                System.out.println("Giorno: " + giornoText);
                System.out.println("Prezzo Minimo: " + prezzoMinText);
                System.out.println("Prezzo Massimo: " + prezzoMaxText);
                System.out.println("Natante: " + natanteText);

                // Esegui la query e popola la tabella
                try {
                    ResultSet rs = controller.consultaTabelloneCorse(partenzaText, arrivoText, dataText, oraText, giornoText, natanteText, prezzoMinText, prezzoMaxText);
                    updateTable(rs); // Aggiorna la tabella con i risultati della query
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    System.err.println("Errore durante l'esecuzione della query: " + ex.getMessage());
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        biglietti.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Chiudi la finestra corrente
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
                frame.dispose();

                // Apri la finestra dei biglietti
                JFrame bigliettiframe = new JFrame("Biglietti");
                bigliettiframe.setContentPane(new Biglietti(controller).bigliettiPanel);
                bigliettiframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                bigliettiframe.pack();
                bigliettiframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
                bigliettiframe.setVisible(true);
            }
        });

        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Chiudi la finestra corrente
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
                frame.dispose();

                // Apri la finestra di login
                JFrame loginframe = new JFrame("Home");
                loginframe.setContentPane(new Home().HomeloginPanel);
                loginframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                loginframe.pack();
                loginframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
                loginframe.setVisible(true);
            }
        });

    }

    private void updateTable(ResultSet rs1) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    DefaultTableModel model = new DefaultTableModel(); // Inizializza il modello dei dati
                    model.setColumnIdentifiers(new Object[]{"idNatante", "idCorsa", "portoPartenza", "portoArrivo", "orarioPartenza", "orarioArrivo", "annullata", "ritardo", "prezzo"}); // Imposta i nomi delle colonne
                    table1.setModel(model); // Imposta il modello dei dati sulla tabella
                    model.setRowCount(0); // Pulisci la tabella prima di aggiungere nuovi dati

                    while (rs1.next()) {
                        // Estrai i dati dal ResultSet
                        int idNatante = rs1.getInt("id_natante");
                        int idCorsa = rs1.getInt("id_corsa");
                        String portoPartenza = rs1.getString("porto_partenza");
                        String portoArrivo = rs1.getString("porto_arrivo");
                        Time orarioPartenza = rs1.getTime("orario_partenza");
                        Time orarioArrivo = rs1.getTime("orario_arrivo");
                        boolean annullata = rs1.getBoolean("annullata");
                        int ritardo = rs1.getInt("ritardo");
                        BigDecimal prezzo = rs1.getBigDecimal("prezzo");

                        // Aggiungi i dati alla tabella
                        model.addRow(new Object[]{
                                idNatante,
                                idCorsa,
                                portoPartenza,
                                portoArrivo,
                                orarioPartenza,
                                orarioArrivo,
                                annullata,
                                ritardo,
                                prezzo
                        });
                    }

                    table1.repaint();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    System.err.println("Errore durante l'aggiornamento della tabella: " + ex.getMessage());
                }
            }
        });
    }


    private void createUIComponents() {
        // TODO: place custom component creation code here
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        Tabellone = new JPanel();
        Tabellone.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(2, 1, new Insets(0, 0, 0, 0), -1, -1));
        Tabellone.setBackground(new Color(-2621457));
        final JPanel panel1 = new JPanel();
        panel1.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(6, 5, new Insets(0, 0, 0, 0), -1, -1));
        panel1.setBackground(new Color(-920589));
        Tabellone.add(panel1, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        panel1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), null, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, null, null));
        ListaP = new JPanel();
        ListaP.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        ListaP.setBackground(new Color(-920589));
        panel1.add(ListaP, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label1 = new JLabel();
        Font label1Font = this.$$$getFont$$$("Calibri", -1, 20, label1.getFont());
        if (label1Font != null) label1.setFont(label1Font);
        label1.setText("Corse");
        ListaP.add(label1);
        Lista = new JScrollPane();
        Lista.setBackground(new Color(-16777216));
        Lista.setForeground(new Color(-13800731));
        ListaP.add(Lista);
        Lista.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(-16777216)), null, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, null, null));
        table1 = new JTable();
        table1.setBackground(new Color(-131073));
        table1.setDropMode(DropMode.ON_OR_INSERT_ROWS);
        table1.setForeground(new Color(-16777216));
        table1.setGridColor(new Color(-16777216));
        Lista.setViewportView(table1);
        TitoloP = new JPanel();
        TitoloP.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        TitoloP.setBackground(new Color(-16777216));
        panel1.add(TitoloP, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 5, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label2 = new JLabel();
        Font label2Font = this.$$$getFont$$$(null, -1, 36, label2.getFont());
        if (label2Font != null) label2.setFont(label2Font);
        label2.setForeground(new Color(-920589));
        label2.setText("TABELLONE CORSE");
        TitoloP.add(label2);
        IndietroP = new JPanel();
        IndietroP.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        panel1.add(IndietroP, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 5, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        login = new JButton();
        login.setBackground(new Color(-131073));
        Font loginFont = this.$$$getFont$$$(null, -1, 20, login.getFont());
        if (loginFont != null) login.setFont(loginFont);
        login.setForeground(new Color(-16777216));
        login.setText("<- Login");
        IndietroP.add(login, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        biglietti = new JButton();
        biglietti.setBackground(new Color(-131073));
        Font bigliettiFont = this.$$$getFont$$$(null, -1, 20, biglietti.getFont());
        if (bigliettiFont != null) biglietti.setFont(bigliettiFont);
        biglietti.setForeground(new Color(-16777216));
        biglietti.setText("Biglietti ->");
        IndietroP.add(biglietti, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        Filtri1P = new JPanel();
        Filtri1P.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        Filtri1P.setBackground(new Color(-920589));
        panel1.add(Filtri1P, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label3 = new JLabel();
        label3.setText("Porto partenza");
        Filtri1P.add(label3);
        partenza = new JTextField();
        partenza.setColumns(10);
        Filtri1P.add(partenza);
        final JLabel label4 = new JLabel();
        label4.setText("Porto arrivo");
        Filtri1P.add(label4);
        arrivo = new JTextField();
        arrivo.setColumns(10);
        Filtri1P.add(arrivo);
        final JLabel label5 = new JLabel();
        label5.setText("Data");
        Filtri1P.add(label5);
        data = new JTextField();
        data.setColumns(5);
        Filtri1P.add(data);
        final JLabel label6 = new JLabel();
        label6.setText("Ora");
        Filtri1P.add(label6);
        ora = new JTextField();
        ora.setColumns(5);
        Filtri1P.add(ora);
        final JLabel label7 = new JLabel();
        label7.setText("Giorno");
        Filtri1P.add(label7);
        giorno = new JTextField();
        giorno.setColumns(5);
        Filtri1P.add(giorno);
        FiltroNP = new JPanel();
        FiltroNP.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        panel1.add(FiltroNP, new com.intellij.uiDesigner.core.GridConstraints(4, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label8 = new JLabel();
        Font label8Font = this.$$$getFont$$$("Calibri", Font.ITALIC, 20, label8.getFont());
        if (label8Font != null) label8.setFont(label8Font);
        label8.setText("Natante");
        FiltroNP.add(label8);
        lista_natanti = new JComboBox();
        Font lista_natantiFont = this.$$$getFont$$$("Calibri", -1, -1, lista_natanti.getFont());
        if (lista_natantiFont != null) lista_natanti.setFont(lista_natantiFont);
        final DefaultComboBoxModel defaultComboBoxModel1 = new DefaultComboBoxModel();
        defaultComboBoxModel1.addElement("");
        defaultComboBoxModel1.addElement("Motonave");
        defaultComboBoxModel1.addElement("Aliscafo");
        defaultComboBoxModel1.addElement("Traghetto");
        lista_natanti.setModel(defaultComboBoxModel1);
        FiltroNP.add(lista_natanti);
        FiltroPP = new JPanel();
        FiltroPP.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        panel1.add(FiltroPP, new com.intellij.uiDesigner.core.GridConstraints(4, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label9 = new JLabel();
        Font label9Font = this.$$$getFont$$$("Calibri", Font.ITALIC, 20, label9.getFont());
        if (label9Font != null) label9.setFont(label9Font);
        label9.setText("Prezzo min");
        FiltroPP.add(label9);
        prezzo_min = new JTextField();
        prezzo_min.setColumns(5);
        FiltroPP.add(prezzo_min);
        final JLabel label10 = new JLabel();
        Font label10Font = this.$$$getFont$$$("Calibri", Font.ITALIC, 20, label10.getFont());
        if (label10Font != null) label10.setFont(label10Font);
        label10.setText("Prezzo max");
        FiltroPP.add(label10);
        prezzo_max = new JTextField();
        prezzo_max.setColumns(5);
        FiltroPP.add(prezzo_max);
        INVIA = new JButton();
        Font INVIAFont = this.$$$getFont$$$(null, -1, 20, INVIA.getFont());
        if (INVIAFont != null) INVIA.setFont(INVIAFont);
        INVIA.setText("INVIA");
        panel1.add(INVIA, new com.intellij.uiDesigner.core.GridConstraints(5, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return Tabellone;
    }

}
