package GUI;

import Controller.*;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;

public class Registrati {
    public Container registratiPanel;
    private JPanel panel1;
    private JLabel titolo;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JPasswordField passwordField1;
    private JButton InviaP;
    private JPanel titolo_passeggero;
    private JPanel nome_p;
    private JPanel cognome_p;
    private JPanel età_p;
    private JPanel codice_fiscale_p;
    private JPanel password_p;
    private JPanel invia_p;
    private JPanel titolo_compagnia;
    private JPanel nome_c;
    private JPanel social_c;
    private JPanel sito_c;
    private JPanel telefono_c;
    private JPanel email_c;
    private JPanel password_c;
    private JPanel invia_c;
    private JPanel IndietroP;
    private JButton login;
    private JButton InviaC;
    private JTextField nomeC;
    private JTextField socialC;
    private JTextField sitoC;
    private JTextField telefonoC;
    private JTextField emailC;
    private JPasswordField passwordC;
    private Controller controller;

    public Registrati(Controller controller) {

        this.controller = controller;
        registratiPanel = panel1;

        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Chiudi la finestra corrente
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
                frame.dispose();

                // Apri la finestra di login
                JFrame loginframe = new JFrame("Home");
                loginframe.setContentPane(new Home().HomeloginPanel);
                loginframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                loginframe.pack();
                loginframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
                loginframe.setVisible(true);
            }
        });

        InviaP.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    controller.setPasseggero(textField1.getText(), textField2.getText(), Integer.parseInt(textField4.getText()), textField3.getText(), passwordField1.getText());

                    // Chiudi la finestra corrente
                    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
                    frame.dispose();

                    // Apri la finestra di login
                    JFrame loginframe = new JFrame("Home");
                    loginframe.setContentPane(new Home().HomeloginPanel);
                    loginframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    loginframe.pack();
                    loginframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
                    loginframe.setVisible(true);
                } catch (LunghezzaMinimaException exception) {
                    JOptionPane.showMessageDialog(null, "La password deve essere lunga almeno 6 caratteri.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (CodiceFiscaleLunghezzaException exception) {
                    JOptionPane.showMessageDialog(null, "Il codice fiscale deve essere lungo 16 caratteri.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (GiaEsistenteException exception) {
                    JOptionPane.showMessageDialog(null, "Il codice fiscale è già presente nel database.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (InvalidRegisterException exception) {
                    JOptionPane.showMessageDialog(null, "Inserire tutti i campi.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, "Errore durante l'inserimento del passeggero: " + exception.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                }
            }
        });

        InviaC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    controller.setCompagnia(nomeC.getText(), telefonoC.getText(), emailC.getText(), sitoC.getText(), socialC.getText(), passwordC.getText());

                    // Chiudi la finestra corrente
                    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
                    frame.dispose();

                    // Apri la finestra di login
                    JFrame loginframe = new JFrame("Home");
                    loginframe.setContentPane(new Home().HomeloginPanel);
                    loginframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    loginframe.pack();
                    loginframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
                    loginframe.setVisible(true);
                } catch (LunghezzaMinimaException exception) {
                    JOptionPane.showMessageDialog(null, "La password deve essere lunga almeno 6 caratteri.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (NomeEsistenteException exception) {
                    JOptionPane.showMessageDialog(null, "Il nome della compagnia è già presente nel database.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (GiaEsistenteException exception) {
                    JOptionPane.showMessageDialog(null, "L'email della compagnia è già presente nel database.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (IsValidEmailException exception) {
                    JOptionPane.showMessageDialog(null, "Inserire un'email valida.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (LunghezzaTelefonoException exception) {
                    JOptionPane.showMessageDialog(null, "Il telefono deve essere lungo 10 caratteri.", "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, "Errore durante l'inserimento della compagnia: " + exception.getMessage(), "Errore", JOptionPane.ERROR_MESSAGE);
                    exception.printStackTrace();
                }
            }
        });


    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());
        panel1.setBackground(new Color(-3538962));
        panel1.setForeground(new Color(-16777216));
        titolo_passeggero = new JPanel();
        titolo_passeggero.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        titolo_passeggero.setBackground(new Color(-131073));
        titolo_passeggero.setForeground(new Color(-16777216));
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(titolo_passeggero, gbc);
        titolo_passeggero.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), null, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, null, null));
        titolo = new JLabel();
        Font titoloFont = this.$$$getFont$$$("Century Gothic", -1, 36, titolo.getFont());
        if (titoloFont != null) titolo.setFont(titoloFont);
        titolo.setText("REGISTRATI PASSEGGERO");
        titolo_passeggero.add(titolo);
        nome_p = new JPanel();
        nome_p.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        nome_p.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(nome_p, gbc);
        final JLabel label1 = new JLabel();
        Font label1Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label1.getFont());
        if (label1Font != null) label1.setFont(label1Font);
        label1.setText("Nome");
        nome_p.add(label1, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        textField1 = new JTextField();
        textField1.setColumns(10);
        textField1.setHorizontalAlignment(2);
        nome_p.add(textField1, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        cognome_p = new JPanel();
        cognome_p.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        cognome_p.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(cognome_p, gbc);
        final JLabel label2 = new JLabel();
        Font label2Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label2.getFont());
        if (label2Font != null) label2.setFont(label2Font);
        label2.setText("Cognome");
        cognome_p.add(label2, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        textField2 = new JTextField();
        textField2.setColumns(10);
        cognome_p.add(textField2, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        età_p = new JPanel();
        età_p.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        età_p.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(età_p, gbc);
        final JLabel label3 = new JLabel();
        Font label3Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label3.getFont());
        if (label3Font != null) label3.setFont(label3Font);
        label3.setText("Età");
        età_p.add(label3, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        textField4 = new JTextField();
        textField4.setColumns(10);
        età_p.add(textField4, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        codice_fiscale_p = new JPanel();
        codice_fiscale_p.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        codice_fiscale_p.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(codice_fiscale_p, gbc);
        final JLabel label4 = new JLabel();
        Font label4Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label4.getFont());
        if (label4Font != null) label4.setFont(label4Font);
        label4.setText("Codice Fiscale");
        codice_fiscale_p.add(label4, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        textField3 = new JTextField();
        textField3.setColumns(10);
        codice_fiscale_p.add(textField3, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        password_p = new JPanel();
        password_p.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(2, 2, new Insets(0, 0, 0, 0), -1, -1));
        password_p.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(password_p, gbc);
        final JLabel label5 = new JLabel();
        Font label5Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label5.getFont());
        if (label5Font != null) label5.setFont(label5Font);
        label5.setText("Password");
        password_p.add(label5, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        passwordField1 = new JPasswordField();
        passwordField1.setColumns(10);
        password_p.add(passwordField1, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        invia_p = new JPanel();
        invia_p.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        invia_p.setBackground(new Color(-3538962));
        password_p.add(invia_p, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        InviaP = new JButton();
        InviaP.setBackground(new Color(-15805440));
        Font InviaPFont = this.$$$getFont$$$(null, -1, 20, InviaP.getFont());
        if (InviaPFont != null) InviaP.setFont(InviaPFont);
        InviaP.setForeground(new Color(-16777216));
        InviaP.setHorizontalAlignment(0);
        InviaP.setHorizontalTextPosition(0);
        InviaP.setText("Invia");
        invia_p.add(InviaP);
        titolo_compagnia = new JPanel();
        titolo_compagnia.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        titolo_compagnia.setBackground(new Color(-131073));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(titolo_compagnia, gbc);
        titolo_compagnia.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), null, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, null, null));
        final JLabel label6 = new JLabel();
        Font label6Font = this.$$$getFont$$$("Century Gothic", -1, 36, label6.getFont());
        if (label6Font != null) label6.setFont(label6Font);
        label6.setText("REGISTRATI COMPAGNIA");
        titolo_compagnia.add(label6);
        nome_c = new JPanel();
        nome_c.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        nome_c.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(nome_c, gbc);
        final JLabel label7 = new JLabel();
        Font label7Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label7.getFont());
        if (label7Font != null) label7.setFont(label7Font);
        label7.setText("Nome*");
        nome_c.add(label7, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        nomeC = new JTextField();
        nomeC.setColumns(10);
        nomeC.setHorizontalAlignment(2);
        nome_c.add(nomeC, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        social_c = new JPanel();
        social_c.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        social_c.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(social_c, gbc);
        final JLabel label8 = new JLabel();
        Font label8Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label8.getFont());
        if (label8Font != null) label8.setFont(label8Font);
        label8.setText("Social");
        social_c.add(label8, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        socialC = new JTextField();
        socialC.setColumns(10);
        socialC.setHorizontalAlignment(2);
        social_c.add(socialC, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        sito_c = new JPanel();
        sito_c.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        sito_c.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 10;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(sito_c, gbc);
        final JLabel label9 = new JLabel();
        Font label9Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label9.getFont());
        if (label9Font != null) label9.setFont(label9Font);
        label9.setText("Sito Web");
        sito_c.add(label9, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        sitoC = new JTextField();
        sitoC.setColumns(10);
        sitoC.setHorizontalAlignment(2);
        sito_c.add(sitoC, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        telefono_c = new JPanel();
        telefono_c.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        telefono_c.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 11;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(telefono_c, gbc);
        final JLabel label10 = new JLabel();
        Font label10Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label10.getFont());
        if (label10Font != null) label10.setFont(label10Font);
        label10.setText("Telefono*");
        telefono_c.add(label10, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        telefonoC = new JTextField();
        telefonoC.setColumns(10);
        telefonoC.setHorizontalAlignment(2);
        telefono_c.add(telefonoC, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        email_c = new JPanel();
        email_c.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        email_c.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 12;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(email_c, gbc);
        final JLabel label11 = new JLabel();
        Font label11Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label11.getFont());
        if (label11Font != null) label11.setFont(label11Font);
        label11.setText("Email*");
        email_c.add(label11, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        emailC = new JTextField();
        emailC.setColumns(10);
        emailC.setHorizontalAlignment(2);
        email_c.add(emailC, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        password_c = new JPanel();
        password_c.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(2, 3, new Insets(0, 0, 0, 0), -1, -1));
        password_c.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 13;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(password_c, gbc);
        final JLabel label12 = new JLabel();
        Font label12Font = this.$$$getFont$$$("Georgia", Font.PLAIN, 28, label12.getFont());
        if (label12Font != null) label12.setFont(label12Font);
        label12.setText("Password*");
        password_c.add(label12, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        passwordC = new JPasswordField();
        passwordC.setColumns(10);
        password_c.add(passwordC, new com.intellij.uiDesigner.core.GridConstraints(0, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        invia_c = new JPanel();
        invia_c.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        invia_c.setBackground(new Color(-3538962));
        password_c.add(invia_c, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        InviaC = new JButton();
        InviaC.setBackground(new Color(-15805440));
        Font InviaCFont = this.$$$getFont$$$(null, -1, 20, InviaC.getFont());
        if (InviaCFont != null) InviaC.setFont(InviaCFont);
        InviaC.setForeground(new Color(-16777216));
        InviaC.setHorizontalAlignment(0);
        InviaC.setHorizontalTextPosition(0);
        InviaC.setText("Invia");
        invia_c.add(InviaC);
        IndietroP = new JPanel();
        IndietroP.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        IndietroP.setBackground(new Color(-3538962));
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.BOTH;
        panel1.add(IndietroP, gbc);
        login = new JButton();
        login.setBackground(new Color(-131073));
        Font loginFont = this.$$$getFont$$$(null, -1, 20, login.getFont());
        if (loginFont != null) login.setFont(loginFont);
        login.setForeground(new Color(-16777216));
        login.setHorizontalAlignment(0);
        login.setHorizontalTextPosition(0);
        login.setText("<- Login");
        IndietroP.add(login);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return panel1;
    }

}
