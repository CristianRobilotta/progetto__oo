package postgresDAO;

import DAO.Interfaccia_DAO;
import DataBase.ConnessioneDatabase;
import Model.Passeggero;
import Model.Compagnia;

import java.math.BigDecimal;


import java.sql.*;

public class Implementazione_postgres_DAO implements Interfaccia_DAO {

    private Connection connection;

    public Implementazione_postgres_DAO() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            System.err.println("Errore durante la connessione al database.");
            e.printStackTrace();
        }
    }

    public void setNatante(String Nome, int Anno, String Modello, int Velocità, int CapacitàPersone, int CapacitàAutomezzi, String Tipo) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("CALL inserisci_natante(?, ?, ?, ?, ?, ?, ?)")){
            preparedStatement.setString(1, Nome);
            preparedStatement.setInt(2, Anno);
            preparedStatement.setString(3, Modello);
            preparedStatement.setInt(4, Velocità);
            preparedStatement.setInt(5, CapacitàPersone);
            preparedStatement.setInt(6, CapacitàAutomezzi);
            preparedStatement.setString(7, Tipo);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Errore durante l'inserimento del natante");
            e.printStackTrace();
        }
    }

// la compagnia lo userà per inserire una corsa nel database
    @Override

    public void setCorsa(String PortoPartenza, String PortoArrivo, String OrarioPartenza, String OrarioArrivo, String TipoNatante, String[] Nome, String PrezzoIntero, String nomeCompagnia, boolean Scalo, String[] PortiScali, Time[] OrariPartenzaScali, Time[] OrariArrivoScali, BigDecimal[] PrezziScali, String DataInizio, String DataFine) {
        try (CallableStatement callableStatement = connection.prepareCall("CALL inserisci_corsa(?, ?, ?::time, ?::time, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?::date, ?::date)"))  {
            // Imposta i parametri
            callableStatement.setString(1, PortoPartenza);
            callableStatement.setString(2, PortoArrivo);
            callableStatement.setString(3, OrarioPartenza);
            callableStatement.setString(4, OrarioArrivo);
            callableStatement.setString(5, TipoNatante);
            callableStatement.setArray(6, connection.createArrayOf("VARCHAR", Nome));
            // Supponendo che PrezzoIntero sia la stringa contenente il valore numerico
            BigDecimal prezzoNumeric = new BigDecimal(PrezzoIntero);

// Imposta il parametro come numeric usando la conversione esplicita
            callableStatement.setBigDecimal(7, prezzoNumeric);

            callableStatement.setString(8, nomeCompagnia);
            callableStatement.setBoolean(9, Scalo);
            callableStatement.setArray(10, connection.createArrayOf("VARCHAR", PortiScali));
            callableStatement.setArray(11, connection.createArrayOf("TIME", OrariPartenzaScali));
            callableStatement.setArray(12, connection.createArrayOf("TIME", OrariArrivoScali));
            callableStatement.setArray(13, connection.createArrayOf("NUMERIC", PrezziScali));
            callableStatement.setString(14, DataInizio);
            callableStatement.setString(15, DataFine);

            // Esegui la stored procedure
            callableStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }




    // la compagnia lo userà per aggiornare le informazioni di una corsa
    public void aggiornaInformazioniCorsa(Integer idCorsa, boolean annullata, Integer ritardo) {
        PreparedStatement updateStatement = null;

        try {
            // Operazioni di aggiornamento della corsa nel database
            String query = "CALL aggiorna_informazioni_corsa(?, ?, ?)";
            updateStatement = connection.prepareStatement(query);
            updateStatement.setInt(1, idCorsa);
            updateStatement.setBoolean(2, annullata);
            updateStatement.setInt(3, ritardo);

            updateStatement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Errore durante l'aggiornamento delle informazioni di una corsa nel database: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                // Chiusura delle risorse legate al database
                if (updateStatement != null) {
                    updateStatement.close();
                }
            } catch (SQLException e) {
                System.err.println("Errore durante la chiusura delle risorse: " + e.getMessage());
            }
        }
    }


    @Override
    public void setPasseggero(String nome, String cognome, int età, String codiceFiscale, String password) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO passeggero (nome, cognome, età, codice_fiscale, password) VALUES (?, ?, ?, ?, ?)")) {
            preparedStatement.setString(1, nome);
            preparedStatement.setString(2, cognome);
            preparedStatement.setInt(3, età);
            preparedStatement.setString(4, codiceFiscale);
            preparedStatement.setString(5, password);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Errore durante l'inserimento di un passeggero nel database.");
            e.printStackTrace();
        }
    }


    // ritorna il passeggero con l'email passata come parametro
    public Passeggero getPasseggero(String codiceFiscale) {
        PreparedStatement selectPasseggero = null;
        Passeggero p = null;
        ResultSet rs = null;
        try {
            String query = "SELECT nome, cognome, codice_fiscale, età, password FROM passeggero WHERE codice_fiscale = ?";
            selectPasseggero = connection.prepareStatement(query);
            selectPasseggero.setString(1, codiceFiscale);
            rs = selectPasseggero.executeQuery();
            if (rs.next()) {
                p = new Passeggero(rs.getString("nome"), rs.getString("cognome"), rs.getString("codice_fiscale"), rs.getInt("età"), rs.getString("password"));
            }
        } catch (SQLException e) {
            System.out.println("Errore durante l'estrazione del passeggero: " + e.getMessage());
        } finally {
            try {
                if (selectPasseggero != null) {
                    selectPasseggero.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("Errore durante la chiusura dello statement: " + e.getMessage());
            }
        }
        return p;
    }


    // il passeggero lo userà per comprare un biglietto
    public ResultSet compraBiglietto(int idCorsa, String codiceFiscale, String pesoBagaglio, int numero,
                                     String data, boolean sovraprezzoAutomezzo, Integer annoProduzioneAutomezzo,
                                     String targaAutomezzo, String marcaAutomezzo, String tipoAutomezzo) {
        try {
            CallableStatement callableStatement = connection.prepareCall("{CALL calcola_prezzo_biglietto(?, ?, ?, ?, ?::date, ?, ?, ?, ?, ?)}");
            callableStatement.setInt(1, idCorsa);
            callableStatement.setString(2, codiceFiscale);
            BigDecimal pesoBagaglioNumeric = new BigDecimal(pesoBagaglio);
            callableStatement.setBigDecimal(3, pesoBagaglioNumeric);
            callableStatement.setInt(4, numero);
            callableStatement.setString(5, data);
            callableStatement.setBoolean(6, sovraprezzoAutomezzo);

            // Debug: stampa i valori dei parametri
            System.out.println("Parametri della stored procedure:");
            System.out.println("idCorsa: " + idCorsa);
            System.out.println("codiceFiscale: " + codiceFiscale);
            System.out.println("pesoBagaglio: " + pesoBagaglio);
            System.out.println("numero: " + numero);
            System.out.println("data: " + data);
            System.out.println("sovraprezzoAutomezzo: " + sovraprezzoAutomezzo);
            System.out.println("annoProduzioneAutomezzo: " + annoProduzioneAutomezzo);
            System.out.println("targaAutomezzo: " + targaAutomezzo);
            System.out.println("marcaAutomezzo: " + marcaAutomezzo);
            System.out.println("tipoAutomezzo: " + tipoAutomezzo);

            // Impostazione dei parametri null per l'automezzo se sovraprezzoAutomezzo è false
            if (!sovraprezzoAutomezzo) {
                callableStatement.setNull(7, Types.INTEGER); // Anno di produzione dell'automezzo
                callableStatement.setString(8, null); // Targa dell'automezzo
                callableStatement.setString(9, null); // Marca dell'automezzo
                callableStatement.setString(10, null); // Tipo dell'automezzo
            } else {
                callableStatement.setInt(7, annoProduzioneAutomezzo);
                callableStatement.setString(8, targaAutomezzo);
                callableStatement.setString(9, marcaAutomezzo);
                callableStatement.setString(10, tipoAutomezzo);
            }
            System.out.println("Executing query: " + callableStatement.toString());

            ResultSet rs = callableStatement.executeQuery();

            // Debug: stampa messaggio di conferma
            if (rs != null) {
                System.out.println("ResultSet non è null. Numero di righe: " + rs.getFetchSize());
            } else {
                System.out.println("ResultSet è null.");
            }

            return rs; // Restituisce il ResultSet direttamente senza ulteriori controlli
        } catch (SQLException e) {
            e.printStackTrace();
            // Debug: stampa messaggio di errore
            System.err.println("Errore durante l'esecuzione della query: " + e.getMessage());
            return null;
        }
    }



    //il passeggero lo userà per annullare una prenotazione
    public void annullaPrenotazione(int idPrenotazione) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("CALL annulla_prenotazione(?)")) {
            preparedStatement.setInt(1, idPrenotazione);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Errore durante l'annullamento di una prenotazione.");
            e.printStackTrace();
    }
}


// Il passeggero lo userà per vedere il tabellone delle corse
public ResultSet consultaTabelloneCorse(String portoPartenza, String portoArrivo, String dataConsulta, String orarioConsulta, String giorno, String tipoNatante, String prezzoMin, String prezzoMax) {
    try {
        CallableStatement callableStatement = connection.prepareCall("{CALL consulta_tabellone_corse(?, ?, ?::date, ?::time, ?, ?, ?, ?)}");
        callableStatement.setString(1, portoPartenza);
        callableStatement.setString(2, portoArrivo);
        callableStatement.setString(3, dataConsulta);
        callableStatement.setString(4, orarioConsulta);
        callableStatement.setString(5, giorno);

        // Gestione del tipo natante come null se è vuoto
        if (tipoNatante != null && !tipoNatante.isEmpty()) {
            callableStatement.setString(6, tipoNatante);
        } else {
            callableStatement.setNull(6, Types.VARCHAR);
        }

        // Gestione dei valori null per i parametri prezzoMin e prezzoMax
        BigDecimal prezzoMinNumeric = null;
        BigDecimal prezzoMaxNumeric = null;
        if (prezzoMin != null && !prezzoMin.isEmpty()) {
            prezzoMinNumeric = new BigDecimal(prezzoMin);
        }
        if (prezzoMax != null && !prezzoMax.isEmpty()) {
            prezzoMaxNumeric = new BigDecimal(prezzoMax);
        }

        callableStatement.setBigDecimal(7, prezzoMinNumeric);
        callableStatement.setBigDecimal(8, prezzoMaxNumeric);

        System.out.println("Executing query: " + callableStatement.toString());

        ResultSet rs1 = callableStatement.executeQuery();

        return rs1;
    } catch (SQLException e) {
        e.printStackTrace();
        return null;
    }
}




    public void setCompagnia(String nome, String telefono, String email, String sitoWeb, String social, String password) {

        // inserimento dei dati nel database
        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO compagnia (nome, telefono, email, sitoweb, social, password) VALUES (?, ?, ?, ?, ?, ?)")) {
            preparedStatement.setString(1, nome);
            preparedStatement.setString(2, telefono);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, sitoWeb);
            preparedStatement.setString(5, social);
            preparedStatement.setString(6, password);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Errore durante l'inserimento di una compagnia nel database.");
            e.printStackTrace();
        }
    }

//metodo per ottenere una compagnia tramite nome
    public Compagnia getCompagniaNome(String nome){
        PreparedStatement selectCompagnia = null;
        Compagnia c = null;
        ResultSet rs = null;
        try {
            String query = "SELECT * FROM compagnia WHERE nome = ?";
            selectCompagnia = connection.prepareStatement(query);
            selectCompagnia.setString(1, nome);
            rs = selectCompagnia.executeQuery();
            if(rs.next()) {
                c = new Compagnia(
                        rs.getString("nome"),
                        rs.getInt("telefono"),
                        rs.getString("email"),
                        rs.getString("sitoweb"),
                        rs.getString("social"),
                        rs.getString("password")
                );
            }
        } catch (SQLException e) {
            System.out.println("Errore durante l'estrazione della compagnia: " + e.getMessage());
        } finally {
            try {
                if (selectCompagnia != null) {
                    selectCompagnia.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("Errore durante la chiusura dello statement: " + e.getMessage());
            }
        }
        return c;
    }
    public Compagnia getCompagnia(String email){
        PreparedStatement selectCompagnia = null;
        Compagnia c = null;
        ResultSet rs = null;
        try {
            String query = "SELECT * FROM compagnia WHERE email = ?";
            selectCompagnia = connection.prepareStatement(query);
            selectCompagnia.setString(1, email);
            rs = selectCompagnia.executeQuery();
            if(rs.next()) {
                c = new Compagnia(
                        rs.getString("nome"),
                        rs.getInt("telefono"),
                        rs.getString("email"),
                        rs.getString("sitoweb"),
                        rs.getString("social"),
                        rs.getString("password")
                );
            }
        } catch (SQLException e) {
            System.out.println("Errore durante l'estrazione della compagnia: " + e.getMessage());
        } finally {
            try {
                if (selectCompagnia != null) {
                    selectCompagnia.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("Errore durante la chiusura dello statement: " + e.getMessage());
            }
        }
        return c;
    }

}
