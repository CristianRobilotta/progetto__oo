package DAO;


import Model.Passeggero;
import Model.Compagnia;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.Time;


public interface Interfaccia_DAO {

   void setNatante(String Nome, int Anno, String Modello, int Velocità, int CapacitàPersone, int CapacitàAutomezzi, String Tipo);
    void setCorsa(String PortoPartenza, String PortoArrivo, String OrarioPartenza, String OrarioArrivo, String TipoNatante, String[] Nome, String PrezzoIntero, String nomeCompagnia, boolean Scalo, String[] PortiScali, Time[] OrariPartenzaScali, Time[] OrariArrivoScali, BigDecimal[] PrezziScali, String DataInizio, String DataFine);


    void aggiornaInformazioniCorsa(Integer idCorsa, boolean annullata, Integer ritardo);


    public Passeggero getPasseggero(String codiceFiscale);

  ResultSet compraBiglietto(int idCorsa, String codiceFiscale, String pesoBagaglio, int numero,
                                String data, boolean sovraprezzoAutomezzo, Integer annoProduzioneAutomezzo,
                                String targaAutomezzo, String marcaAutomezzo, String tipoAutomezzo);

    void annullaPrenotazione(int idPrenotazione);

    ResultSet consultaTabelloneCorse(String portoPartenza, String portoArrivo, String dataConsulta, String orarioConsulta, String giorno, String tipoNatante, String prezzoMin, String prezzoMax);
    void setCompagnia(String nome, String telefono, String email, String sitoWeb, String social, String password);
    Compagnia getCompagnia(String email);

    Compagnia getCompagniaNome(String nome);

    void setPasseggero(String nome, String cognome, int età, String codiceFiscale, String password);
}


