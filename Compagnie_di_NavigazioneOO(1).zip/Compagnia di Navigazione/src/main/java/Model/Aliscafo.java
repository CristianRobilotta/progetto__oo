package Model;
public class Aliscafo {
    private String capacitaPersone;
    private String velocitaMassima;
    private String modello;
    private String idAliscafo;
    private int annoProduzione;

    public Aliscafo(String capacitaPersone, String velocitaMassima, String modello, String idAliscafo, int annoProduzione) {
    }

    public Aliscafo(String idAliscafo, int capacitaPersone, int velocitaMassima, String modello, int annoProduzione) {
    }

    public String getCapacitaPersone() {
        return capacitaPersone;
    }

    public void setCapacitaPersone(String capacitaPersone) {
        this.capacitaPersone = capacitaPersone;
    }

    public String getVelocitaMassima() {
        return velocitaMassima;
    }

    public void setVelocitaMassima(String velocitaMassima) {
        this.velocitaMassima = velocitaMassima;
    }

    public String getModello() {
        return modello;
    }

    public void setModello(String modello) {
        this.modello = modello;
    }

    public String getIdAliscafo() {
        return idAliscafo;
    }

    public void setIdAliscafo(String idAliscafo) {
        this.idAliscafo = idAliscafo;
    }

    public int getAnnoProduzione() {
        return annoProduzione;
    }

    public void setAnnoProduzione(int annoProduzione) {
        this.annoProduzione = annoProduzione;
    }
}
