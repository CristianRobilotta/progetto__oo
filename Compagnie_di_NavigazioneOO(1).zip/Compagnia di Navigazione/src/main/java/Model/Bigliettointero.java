package Model;
public class Bigliettointero {
    private float prezzo;
    private int idIntero;

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public int getIdIntero() {
        return idIntero;
    }

    public void setIdIntero(int idIntero) {
        this.idIntero = idIntero;
    }

}
