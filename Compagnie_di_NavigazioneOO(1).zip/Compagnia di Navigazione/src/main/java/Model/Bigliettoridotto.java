package Model;

public class Bigliettoridotto {
    private float prezzo;
    private int idRidotto;



    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public int getIdRidotto() {
        return idRidotto;
    }

    public void setIdRidotto(int idRidotto) {
        this.idRidotto = idRidotto;
    }
}
