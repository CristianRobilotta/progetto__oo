package Model;

import java.util.*;

/**
 * 
 */
public class Bagaglio {

    /**
     * Default constructor
     */
    public Bagaglio() {
    }

    /**
     * 
     */
    public int numero;

    /**
     * 
     */
    public float peso;

    /**
     * 
     */
    public int id_bagaglio;



    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public float getPeso() {
        return peso;
    }

}