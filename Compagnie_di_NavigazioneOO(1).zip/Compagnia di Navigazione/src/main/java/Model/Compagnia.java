
package Model;
public class Compagnia {
    private static String nome;
    private int telefono;
    private String email;
    private String sitoWeb;
    private String social;
    private String password;

    public Compagnia(String nome, int telefono, String email, String sitoWeb, String social, String password) {
        this.nome = nome;
        this.telefono = telefono;
        this.email = email;
        this.sitoWeb = sitoWeb;
        this.social = social;
        this.password = password;
    }

    // Getter e setter per gli attributi della compagnia

    public static String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSitoWeb() {
        return sitoWeb;
    }

    public void setSitoWeb(String sitoWeb) {
        this.sitoWeb = sitoWeb;
    }

    public String getSocial() {
        return social;
    }

    public void setSocial(String social) {
        this.social = social;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

}
