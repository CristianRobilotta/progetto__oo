package Model;
import java.util.Date;

public class Automezzo {
    private Date annoProduzione;
    private String targa;
    private String marca;
    private String tipo;

    public Automezzo(java.sql.Date annoProduzione, String targa, String marca, String tipo) {
    }

    public Date getAnnoProduzione() {
        return annoProduzione;
    }

    public void setAnnoProduzione(Date annoProduzione) {
        this.annoProduzione = annoProduzione;
    }

    public String getTarga() {
        return targa;
    }

    public void setTarga(String targa) {
        this.targa = targa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}
