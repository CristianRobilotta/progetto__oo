package Model;
import java.util.Date;

public class Prenotazione {

    public Prenotazione() {
    }

    private Date data;
    private String idPrenotazione;

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getIdPrenotazione() {
        return idPrenotazione;
    }

    public void setIdPrenotazione(String idPrenotazione) {
        this.idPrenotazione = idPrenotazione;
    }
}
