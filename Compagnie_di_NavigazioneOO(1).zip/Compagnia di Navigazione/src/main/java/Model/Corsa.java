package Model;

import java.sql.Time;

public class Corsa {
    private int idCorsa;
    private String portoPartenza;
    private String portoArrivo;
    private Time orarioPartenza;
    private Time orarioArrivo;
    private boolean scalo;
    private boolean annullata;
    private String ritardo;
    private float prezzoIntero;
    private float prezzoRidotto;

    // Costruttore
    public Corsa(int idCorsa, String portoPartenza, String portoArrivo, Time orarioPartenza, Time orarioArrivo,
                 boolean scalo, boolean annullata, String ritardo,
                 float prezzoIntero, float prezzoRidotto) {
        this.idCorsa = idCorsa;
        this.portoPartenza = portoPartenza;
        this.portoArrivo = portoArrivo;
        this.orarioPartenza = orarioPartenza;
        this.orarioArrivo = orarioArrivo;
        this.scalo = scalo;
        this.annullata = annullata;
        this.ritardo = ritardo;
        this.prezzoIntero = prezzoIntero;
        this.prezzoRidotto = prezzoRidotto;
    }

    public int getIdCorsa() {
        return idCorsa;
    }
    public void setIdCorsa(int idCorsa) {
        this.idCorsa = idCorsa;
    }
    public String getPortoPartenza() {
        return portoPartenza;
    }
    public void setPortoPartenza(String portoPartenza) {
        this.portoPartenza = portoPartenza;
    }
    public String getPortoArrivo() {
        return portoArrivo;
    }
    public void setPortoArrivo(String portoArrivo) {
        this.portoArrivo = portoArrivo;
    }
    public Time getOrarioPartenza() {
        return orarioPartenza;
    }
    public void setOrarioPartenza(Time orarioPartenza) {
        this.orarioPartenza = orarioPartenza;
    }
    public Time getOrarioArrivo() {
        return orarioArrivo;
    }
    public void setOrarioArrivo(Time orarioArrivo) {
        this.orarioArrivo = orarioArrivo;
    }
    public boolean isScalo() {

        return scalo;
    }

    public void setScalo(boolean scalo) {

        this.scalo = scalo;
    }

    // Getter e setter per annullata
    public boolean isAnnullata() {
        return annullata;
    }

    public void setAnnullata(boolean annullata) {

        this.annullata = annullata;
    }

    // Getter e setter per ritardo
    public String getRitardo() {

        return ritardo;
    }

    public void setRitardo(String ritardo) {
        this.ritardo = ritardo;
    }

    // Getter e setter per prezzoIntero
    public float getPrezzoIntero() {
        return prezzoIntero;
    }

    public void setPrezzoIntero(float prezzoIntero) {
        this.prezzoIntero = prezzoIntero;
    }

    // Getter e setter per prezzoRidotto
    public float getPrezzoRidotto() {
        return prezzoRidotto;
    }

    public void setPrezzoRidotto(float prezzoRidotto) {
        this.prezzoRidotto = prezzoRidotto;
    }


}
