package Model;
public class Traghetto {

    public Traghetto(int idTraghetto, String capacitaAutomezzi, String capacitaPersone, String velocitaMassima, String modello, int annoProduzione) {
    }

    private String capacitaAutomezzi;
    private String capacitaPersone;
    private String velocitaMassima;
    private String modello;
    private int idTraghetto;
    private int annoProduzione;

    public String getCapacitaAutomezzi() {
        return capacitaAutomezzi;
    }

    public void setCapacitaAutomezzi(String capacitaAutomezzi) {
        this.capacitaAutomezzi = capacitaAutomezzi;
    }

    public String getCapacitaPersone() {
        return capacitaPersone;
    }

    public void setCapacitaPersone(String capacitaPersone) {
        this.capacitaPersone = capacitaPersone;
    }

    public String getVelocitaMassima() {
        return velocitaMassima;
    }

    public void setVelocitaMassima(String velocitaMassima) {
        this.velocitaMassima = velocitaMassima;
    }

    public String getModello() {
        return modello;
    }

    public void setModello(String modello) {
        this.modello = modello;
    }

    public int getIdTraghetto() {
        return idTraghetto;
    }

    public void setIdTraghetto(int idTraghetto) {
        this.idTraghetto = idTraghetto;
    }

    public int getAnnoProduzione() {
        return annoProduzione;
    }

    public void setAnnoProduzione(int annoProduzione) {
        this.annoProduzione = annoProduzione;
    }
}
