
package Model;

public class Effettua {
    private boolean sovraprezzo;
    private float prezzo;

    public Effettua(boolean sovraprezzo, float prezzo) {
        this.sovraprezzo = sovraprezzo;
        this.prezzo = prezzo;
    }

    public boolean isSovraprezzo() {
        return sovraprezzo;
    }

    public void setSovraprezzo(boolean sovraprezzo) {
        this.sovraprezzo = sovraprezzo;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }
}
