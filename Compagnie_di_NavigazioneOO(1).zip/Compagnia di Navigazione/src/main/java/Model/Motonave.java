package Model;

public class Motonave {

    public Motonave(int idMotonave, String capacitaPersone, String velocitaMassima, String modello, int annoProduzione) {
    }

    private String capacitaPersone;
    private String velocitaMassima;
    private String modello;
    private int idMotonave;
    private int annoProduzione;

    public String getCapacitaPersone() {
        return capacitaPersone;
    }

    public void setCapacitaPersone(String capacitaPersone) {
        this.capacitaPersone = capacitaPersone;
    }

    public String getVelocitaMassima() {
        return velocitaMassima;
    }

    public void setVelocitaMassima(String velocitaMassima) {
        this.velocitaMassima = velocitaMassima;
    }

    public String getModello() {
        return modello;
    }

    public void setModello(String modello) {
        this.modello = modello;
    }

    public int getIdMotonave() {
        return idMotonave;
    }

    public void setIdMotonave(int idMotonave) {
        this.idMotonave = idMotonave;
    }

    public int getAnnoProduzione() {
        return annoProduzione;
    }

    public void setAnnoProduzione(int annoProduzione) {
        this.annoProduzione = annoProduzione;
    }
}
