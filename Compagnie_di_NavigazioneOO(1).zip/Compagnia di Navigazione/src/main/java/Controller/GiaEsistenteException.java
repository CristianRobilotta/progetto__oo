package Controller;

public class GiaEsistenteException extends Exception {
}
