package Controller;

public class NomeEsistenteException extends Exception {
}
