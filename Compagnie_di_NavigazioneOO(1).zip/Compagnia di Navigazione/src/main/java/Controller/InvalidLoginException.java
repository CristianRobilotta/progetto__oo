package Controller;

public class InvalidLoginException extends Exception {
}
