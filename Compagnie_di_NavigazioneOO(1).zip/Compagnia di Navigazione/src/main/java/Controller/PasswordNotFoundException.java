package Controller;

public class PasswordNotFoundException extends Throwable {
}
