package Controller;

public class EmailNotFoundException extends Throwable {
}
