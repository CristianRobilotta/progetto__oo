package Controller;

import DAO.Interfaccia_DAO;
import Model.Passeggero;
import Model.Compagnia;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.Time;

public class Controller {
    private Passeggero passeggero;
    private Interfaccia_DAO interfacciaDAO;

    public Controller(Interfaccia_DAO interfacciaDAO) {
        this.interfacciaDAO = interfacciaDAO;
    }

    public void setPasseggero(String nome, String cognome, int età, String codiceFiscale, String password) throws GiaEsistenteException, LunghezzaMinimaException, InvalidLoginException, CodiceFiscaleLunghezzaException, InvalidRegisterException {
        if (codiceFiscale.isBlank() || password.isBlank())  {
            throw new InvalidLoginException();
        } else if (password.length() < 6) {
            throw new LunghezzaMinimaException();
        }
        if (codiceFiscale.length() != 16) {
            throw new CodiceFiscaleLunghezzaException();
        }
        if (nome.isBlank() || cognome.isBlank() || età <= 0 || codiceFiscale.isBlank() || password.isBlank()){
            throw new InvalidRegisterException();
        } else if (password.length() < 6) {
            throw new LunghezzaMinimaException();
        }
        if(interfacciaDAO.getPasseggero(codiceFiscale) != null){
            throw new GiaEsistenteException();
           }
        interfacciaDAO.setPasseggero(nome, cognome, età, codiceFiscale, password);

    }


    public void loginPasseggero(String codiceFiscale, String password) throws InvalidLoginException, CodiceFiscaleNotFoundException, PasswordNotFoundException {

        if (codiceFiscale.isBlank() || password.isBlank())
            throw new InvalidLoginException();

        passeggero = interfacciaDAO.getPasseggero(codiceFiscale);

        if (passeggero == null) {
            throw new   CodiceFiscaleNotFoundException();
        } else if (!(passeggero.getPassword().equals(password))) {
            throw new PasswordNotFoundException();
        }
    }
    public void loginCompagnia(String email, String password) throws InvalidLoginException, EmailNotFoundException, PasswordNotFoundException {

        if (email.isBlank() || password.isBlank())
            throw new InvalidLoginException();

        Compagnia compagnia = interfacciaDAO.getCompagnia(email);

        if (compagnia == null) {
            throw new EmailNotFoundException();
        } else if (!(compagnia.getPassword().equals(password))) {
            throw new PasswordNotFoundException();
        }
    }

    public void setCorsa(String PortoPartenza, String PortoArrivo, String OrarioPartenza, String OrarioArrivo, String TipoNatante, String[] Nome, String PrezzoIntero, String nomeCompagnia, boolean Scalo, String[] PortiScali, Time[] OrariPartenzaScali, Time[] OrariArrivoScali, BigDecimal[] PrezziScali, String DataInizio, String DataFine) {
        interfacciaDAO.setCorsa(PortoPartenza, PortoArrivo, OrarioPartenza, OrarioArrivo, TipoNatante, Nome, PrezzoIntero, nomeCompagnia, Scalo, PortiScali, OrariPartenzaScali, OrariArrivoScali, PrezziScali, DataInizio, DataFine);
    }

    // Metodo per aggiornare le informazioni di una corsa
    public void aggiornaInformazioniCorsa(Integer idCorsa, boolean annullata, Integer ritardo) throws Exception {
        interfacciaDAO.aggiornaInformazioniCorsa(idCorsa, annullata, ritardo);
    }


    // Metodo per l'acquisto di un biglietto da parte di un passeggero
    public ResultSet compraBiglietto(int idCorsa, String codiceFiscale, String pesoBagaglio, int numero, String data, boolean sovraprezzoAutomezzo, Integer annoProduzioneAutomezzo, String targaAutomezzo, String marcaAutomezzo, String tipoAutomezzo) throws Exception {
        Interfaccia_DAO.compraBiglietto(idCorsa, codiceFiscale, pesoBagaglio, numero, data, sovraprezzoAutomezzo, annoProduzioneAutomezzo, targaAutomezzo, marcaAutomezzo, tipoAutomezzo);
        return null;
    }

    // Metodo per annullare una prenotazione da parte di un passeggero
    public void annullaPrenotazione(int idPrenotazione) throws Exception {
        interfacciaDAO.annullaPrenotazione(idPrenotazione);
    }

    // Metodo per consultare il tabellone delle corse
    public ResultSet consultaTabelloneCorse(String portoPartenza, String portoArrivo, String dataConsulta, String orarioConsulta, String giorno, String tipoNatante, String prezzoMin, String prezzoMax) throws Exception {
        return interfacciaDAO.consultaTabelloneCorse(portoPartenza, portoArrivo, dataConsulta, orarioConsulta, giorno, tipoNatante, prezzoMin, prezzoMax);
    }

    //Metodo per inserire una compagnia
    public void setCompagnia(String nome, String telefono, String email, String sitoWeb, String social, String password) throws LunghezzaMinimaException, GiaEsistenteException,IsValidEmailException,LunghezzaTelefonoException,NomeEsistenteException {

        //gestione eccezioni
        if (password.length() < 6) {
            throw new LunghezzaMinimaException();
        }
        if (!email.contains("@") || !email.contains(".")) {
            throw new IsValidEmailException();
        }
        // gestione già esistente se l'email è già presente nel database

            if (interfacciaDAO.getCompagnia(email) != null) {
                throw new GiaEsistenteException();
            }
        //gestione nome esistente nel database

            if (interfacciaDAO.getCompagniaNome(nome) != null) {
                throw new NomeEsistenteException();
            }

            //gestione lunghezza telefono di 10
            if (telefono.length() != 10) {
                throw new LunghezzaTelefonoException();
            }

        interfacciaDAO.setCompagnia(nome, telefono, email, sitoWeb, social, password);
        }


    public void setNatante(String Nome, int Anno, String Modello, int Velocità, int CapacitàPersone, int CapacitàAutomezzi, String Tipo){
        interfacciaDAO.setNatante(Nome, Anno, Modello, Velocità, CapacitàPersone, CapacitàAutomezzi, Tipo);

    }
}



