package Controller;

public class CodiceFiscaleNotFoundException extends Exception {
}
