package Controller;

public class IsValidEmailException extends Exception {
}
