package Controller;

public class InvalidRegisterException extends Exception {
}
