package Controller;

public class LunghezzaMinimaException extends Exception {
}
