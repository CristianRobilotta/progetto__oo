package Controller;

public class LunghezzaTelefonoException extends Exception {
}
