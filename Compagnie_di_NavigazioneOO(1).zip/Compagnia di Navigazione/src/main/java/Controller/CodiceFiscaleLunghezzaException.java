package Controller;

public class CodiceFiscaleLunghezzaException extends Exception {
}
